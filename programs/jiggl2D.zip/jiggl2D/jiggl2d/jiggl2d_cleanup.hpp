#ifndef PEGAFOX_JIGGL2D_CLEANUP_HPP
#define PEGAFOX_JIGGL2D_CLEANUP_HPP

using namespace j2;

#include "bottom/collider.hpp"
#include "bottom/pointMass.hpp"
#include "bottom/rope.hpp"
#include "bottom/spring.hpp"

#endif