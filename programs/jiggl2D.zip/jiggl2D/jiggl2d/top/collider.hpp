class Collider : public Mesh {
  public:
    sf::FloatRect bounds;

    Collider();

    Collider(const std::vector<unsigned int>& vertices);

    void update();

    void draw(sf::RenderTarget& SCREEN);
  private:
    sf::ConvexShape sprite;

    // checks if point is in object. If so, returns where to move the point to push it out. Otherwise returns nan
    bool rayCollide(const sf::Vector2f& rayOrigin, sf::Vector2f lineStart, sf::Vector2f lineEnd, sf::Vector2f& closestPoint) {
      glm::vec2 pos = pf::lineClosestPoint(lineStart.x, lineStart.y, lineEnd.x, lineEnd.y, rayOrigin.x, rayOrigin.y);
      closestPoint = sf::Vector2f(pos.x, pos.y);

      bool gtStart = rayOrigin.y > lineStart.y;
      bool gtEnd = rayOrigin.y > lineEnd.y;
      if (gtStart != gtEnd) { // not too high and not too low
        gtStart = rayOrigin.x > lineStart.x;
        gtEnd = rayOrigin.x > lineEnd.x;
        if (!(gtStart && gtEnd)) { // not too far right
          if (!(gtStart || gtEnd)) {
            return true;
          }

          float xVal = lineStart.x + (rayOrigin.y-lineStart.y) / (lineEnd.y-lineStart.y) * (lineEnd.x-lineStart.x);
          if (rayOrigin.x < xVal) {
            return true;
          }
        }
      }
      return false;
    }
};