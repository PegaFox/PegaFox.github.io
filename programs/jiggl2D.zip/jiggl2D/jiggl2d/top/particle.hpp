class Particle : public Object {
  public:
    sf::Vector2f pos;
    bool fixed = false;

  protected:
    sf::CircleShape sprite = sf::CircleShape(0.0f, 6);
};