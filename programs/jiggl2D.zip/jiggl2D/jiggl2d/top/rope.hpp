class Rope : public Connector {
  public:
    float homeDis = 100.0f;
    float stiffness = 1.0f;
    float damping = 1.0f;
    uint32_t durability = -1;

    Rope();

    Rope(float newMaxDis);

    void update();

    void draw(sf::RenderTarget& SCREEN);
  private:
    sf::VertexArray sprite;
};