class Connector : public Object {
  public:
    sf::Vector2u connections;

    virtual void update() = 0;
};