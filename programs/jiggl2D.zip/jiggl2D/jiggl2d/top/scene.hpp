std::vector<Particle*> particles;
std::vector<Connector*> connectors;
std::vector<Mesh*> meshes;

float speed = 1.0f;
