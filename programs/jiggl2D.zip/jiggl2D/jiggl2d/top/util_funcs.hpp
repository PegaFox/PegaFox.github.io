std::string exportData(const std::vector<Object*>& objects) {
  std::string result;

  for (uint64_t o = 0; o < objects.size(); o++) {
    PointMass* pointMass = dynamic_cast<PointMass*>(objects[o]);
    if (pointMass != nullptr) {
      result.append(
        "P "+
        std::to_string(pointMass->pos.x)+
        " "+
        std::to_string(pointMass->pos.y)+
        " "+
        std::to_string(pointMass->fixed)+
        " "+
        std::to_string(pointMass->bounciness)+
        " "+
        std::to_string(pointMass->collisionRadius)+
        " "+
        std::to_string(pointMass->mass)+
        "\n"
      );
    } else {
      Spring* spring = dynamic_cast<Spring*>(objects[o]);
      if (spring != nullptr) {
        result.append(
          "S "+
          std::to_string(spring->connections.x)+
          " "+
          std::to_string(spring->connections.y)+
          " "+
          std::to_string(spring->stiffness)+
          " "+
          std::to_string(spring->damping)+
          " "+
          std::to_string(spring->durability)+
          " "+
          std::to_string(spring->getHomeDis())+
          "\n"
        );
      } else {
        Rope* rope = dynamic_cast<Rope*>(objects[o]);
        if (rope != nullptr) {
          result.append(
            "R "+
            std::to_string(rope->connections.x)+
            " "+
            std::to_string(rope->connections.y)+
            " "+
            std::to_string(rope->stiffness)+
            " "+
            std::to_string(rope->damping)+
            " "+
            std::to_string(rope->durability)+
            " "+
            std::to_string(rope->homeDis)+
            "\n"
          );
        }
      }
    }
  }

  return result;
}

std::vector<Object*> importData(std::string data) {
  std::vector<Object*> result;
  result.reserve(std::count(data.cbegin(), data.cend(), '\n'));

  std::stringstream dataStream(data);
  std::string read;

  while (dataStream >> read) {
    

    switch (read[0]) {
      case 'P': {
        result.push_back(new PointMass());
        PointMass* obj = (PointMass*)result.back();

        dataStream >> read;
        obj->pos.x = std::stof(read);
        dataStream >> read;
        obj->pos.y = std::stof(read);
        dataStream >> read;
        obj->fixed = read == "1";
        dataStream >> read;
        obj->bounciness = std::stof(read);
        dataStream >> read;
        obj->collisionRadius = std::stof(read);
        dataStream >> read;
        obj->mass = std::stof(read);
        
        break;
      } case 'S': {
        result.push_back(new Spring());
        Spring* obj = (Spring*)result.back();

        dataStream >> read;
        obj->connections.x = std::stoul(read);
        dataStream >> read;
        obj->connections.y = std::stoul(read);
        dataStream >> read;
        obj->stiffness = std::stof(read);
        dataStream >> read;
        obj->damping = std::stof(read);
        dataStream >> read;
        obj->durability = std::stoul(read);
        dataStream >> read;
        obj->setHomeDis(std::stof(read));

        break;
      } case 'R': {
        result.push_back(new Rope());
        Rope* obj = (Rope*)result.back();

        dataStream >> read;
        obj->connections.x = std::stoul(read);
        dataStream >> read;
        obj->connections.y = std::stoul(read);
        dataStream >> read;
        obj->stiffness = std::stof(read);
        dataStream >> read;
        obj->damping = std::stof(read);
        dataStream >> read;
        obj->durability = std::stoul(read);
        dataStream >> read;
        obj->homeDis = std::stof(read);

        break;
      } default:

        break;
    }
  }

  return result;
}
