class Spring : public Connector {
  public:
    float stiffness = 1.0f;
    float damping = 1.0f;
    uint32_t durability = -1;

    Spring();

    Spring(float homeDis, const sf::Vector2u& connections = {0U, 0U});

    Spring(const sf::Vector2u& connections, float homeDis = 100.0f);

    void setHomeDis(float newHomeDis);

    float getHomeDis();

    void update();

    void draw(sf::RenderTarget& SCREEN);

  private:
    sf::VertexArray sprite;
    float homeDis;
};