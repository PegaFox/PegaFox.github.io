class PointMass : public Particle {
  public:
    sf::Vector2f velocity = sf::Vector2f(0.0f, 0.0f);
    float bounciness = 0.1f;
    float collisionRadius = 0.0f;
    float mass = 10.0;

    PointMass();

    PointMass(const sf::Vector2f& pos, float mass = 10.0f, float collisionRadius = 0.0f);

    void addForce(sf::Vector2f force);

    void update();

    void draw(sf::RenderTarget& SCREEN);
};