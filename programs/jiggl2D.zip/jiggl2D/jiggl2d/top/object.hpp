enum class Type {
  object,
  particle,
  connector,
  mesh,
  pointMass,
  spring,
  rope,
  collider
};

class Object {
  public:
    virtual void draw(sf::RenderTarget& SCREEN) = 0;
    Type classType = Type::object;
};