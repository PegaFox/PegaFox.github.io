Collider::Collider() {
  classType = Type::collider;

  sprite.setFillColor(sf::Color(255, 255, 255, 128));
  sprite.setPointCount(4);
}

Collider::Collider(const std::vector<unsigned int>& vertices) {
  classType = Type::collider;

  this->vertices = vertices;
  sprite.setFillColor(sf::Color(255, 255, 255, 128));
  sprite.setPointCount(4);
}

void Collider::update() {
  if (sprite.getFillColor() == sf::Color::Red) sprite.setFillColor(sf::Color(255, 255, 255, 128));

  bounds = sprite.getGlobalBounds();
  for (int obj = 0; obj < meshes.size(); obj++) {
    if (((Collider*)meshes[obj])->bounds == bounds) continue;
    if (bounds.intersects(((Collider*)meshes[obj])->bounds)) {
      for (int point = 0; point < meshes[obj]->vertices.size(); point++) {
        PointMass* testPoint = (PointMass*)particles[meshes[obj]->vertices[point]];
        uint32_t total = 0;
        std::vector<sf::Vector2f> closePts;
        for (int line = 0; line < vertices.size(); line++) {
          sf::Vector2f* lineVert1 = &particles[vertices[line]]->pos;
          sf::Vector2f* lineVert2 = &particles[vertices[(line+1)%vertices.size()]]->pos;
          
          closePts.push_back(sf::Vector2f());

          if (rayCollide(testPoint->pos, *lineVert1, *lineVert2, closePts.back())) {
            total++;
          }
        }
        if (total % 2 == 1) {
          float lowDis = pf::distance(testPoint->pos.x, testPoint->pos.y, closePts[0].x, closePts[0].y);
          uint32_t lowInd = 0;
          for (uint32_t p = 1; p < closePts.size(); p++) {
            float dis = pf::distance(testPoint->pos.x, testPoint->pos.y, closePts[p].x, closePts[p].y);
            if (dis < lowDis) {
              lowDis = dis;
              lowInd = p;
            }
          }

          auto movDir = pf::normalize(testPoint->pos.x - closePts[lowInd].x, testPoint->pos.y - closePts[lowInd].y);
          auto vel = pf::reflect(testPoint->velocity.x, testPoint->velocity.y, movDir[0], movDir[1]);
          testPoint->velocity = sf::Vector2f(vel[0], vel[1]) * testPoint->bounciness;
          testPoint->pos += (closePts[lowInd] - testPoint->pos) / 2.0f;

          particles[vertices[lowInd]]->pos -= (closePts[lowInd] - testPoint->pos) / 2.0f;
          particles[vertices[(lowInd+1)%vertices.size()]]->pos -= (closePts[lowInd] - testPoint->pos) / 2.0f;

          ((j2::PointMass*)particles[vertices[lowInd]])->velocity -= (closePts[lowInd] - testPoint->pos) / 2.0f;
          ((j2::PointMass*)particles[vertices[(lowInd+1)%vertices.size()]])->velocity -= (closePts[lowInd] - testPoint->pos) / 2.0f;
        }
      }
    }
  }
}

void Collider::draw(sf::RenderTarget& SCREEN) {
  sprite.setPointCount(vertices.size());
  for (int point = 0; point < vertices.size(); point++) {
    sprite.setPoint(point, particles[vertices[point]]->pos);
  }
  SCREEN.draw(sprite);
}
