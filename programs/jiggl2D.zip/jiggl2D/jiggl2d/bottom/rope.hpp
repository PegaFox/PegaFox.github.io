Rope::Rope() {
  classType = Type::rope;

  sprite.setPrimitiveType(sf::Lines);
  sprite.resize(2);
}

Rope::Rope(float newMaxDis) {
  classType = Type::rope;

  homeDis = newMaxDis;

  sprite.setPrimitiveType(sf::Lines);
  sprite.resize(2);
}

void Rope::update() {
  if (connections.x == connections.y) return;

  float offset = pf::distance(
    particles[connections.x]->pos.x, particles[connections.x]->pos.y,
    particles[connections.y]->pos.x, particles[connections.y]->pos.y
  ) - homeDis;
  if (offset <= 0) return;
  if (offset > durability) {
    connections = sf::Vector2u(-1, -1);
    return;
  }

  auto out = pf::normalize(
    particles[connections.x]->pos.x - particles[connections.y]->pos.x,
    particles[connections.x]->pos.y - particles[connections.y]->pos.y
  );
  sf::Vector2f dir(out[0], out[1]);

  PointMass* pX = (PointMass*)particles[connections.x];
  PointMass* pY = (PointMass*)particles[connections.y];

  sf::Vector2f damped = pX->velocity - pY->velocity * damping;
  float force = offset * stiffness + pf::dotProduct(dir.x, dir.y, damped.x, damped.y);
  pX->addForce(-dir * force);
  pY->addForce(dir * force);
}

void Rope::draw(sf::RenderTarget& SCREEN) {
  if (connections.x == connections.y) return;

  sprite[0].position = particles[connections.x]->pos;
  sprite[1].position = particles[connections.y]->pos;
  SCREEN.draw(sprite);
}