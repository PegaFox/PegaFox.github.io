PointMass::PointMass() {
  classType = Type::pointMass;

  sprite.setOutlineThickness(1.0f);
}

PointMass::PointMass(const sf::Vector2f& pos, float mass, float collisionRadius) {
  classType = Type::pointMass;
  
  this->pos = pos;
  this->mass = mass;
  this->collisionRadius = collisionRadius;
  sprite.setOutlineThickness(1.0f);
}

void PointMass::addForce(sf::Vector2f force) {
  force /= mass;
  force *= speed;
  velocity += force;
}

void PointMass::update() {
  
  if (collisionRadius > 0.0f) {
    for (int p = 0; p < particles.size(); p++) {
      float dis = pf::distance(pos.x, pos.y, particles[p]->pos.x, particles[p]->pos.y);
      PointMass* testPoint = (PointMass*)particles[p];

      if (dis > 0 && dis < collisionRadius+testPoint->collisionRadius) {
        sf::Vector2f ang(pos - particles[p]->pos);
        ang /= dis;
        velocity += ang*((collisionRadius+testPoint->collisionRadius)-dis);
      }
    }
  }

  if (fixed) {
    velocity = sf::Vector2f(0.0f, 0.0f);
  }
  pos += velocity * speed;
}

void PointMass::draw(sf::RenderTarget& SCREEN) {
  sprite.setFillColor(sf::Color::White);
  sprite.setRadius(mass);
  sprite.setOrigin(sf::Vector2f(mass, mass));
  sprite.setPosition(pos);
  SCREEN.draw(sprite);
  sprite.setFillColor(sf::Color::Transparent);
  sprite.setRadius(collisionRadius);
  sprite.setOrigin(sf::Vector2f(collisionRadius, collisionRadius));
  SCREEN.draw(sprite);
}