Spring::Spring() {
  classType = Type::spring;

  setHomeDis(100);
  sprite.setPrimitiveType(sf::LineStrip);
}

Spring::Spring(float homeDis, const sf::Vector2u& connections) {
  classType = Type::spring;

  setHomeDis(homeDis);
  this->connections = connections;
  sprite.setPrimitiveType(sf::LineStrip);
}

Spring::Spring(const sf::Vector2u& connections, float homeDis) {
  this->connections = connections;
  setHomeDis(homeDis);
  sprite.setPrimitiveType(sf::LineStrip);
}

void Spring::setHomeDis(float newHomeDis) {
  homeDis = newHomeDis;
  sprite.resize(floor(homeDis/10)+1);
}

float Spring::getHomeDis() {
  return homeDis;
}

void Spring::update() {
  if (connections.x == connections.y) return;

  float offset = pf::distance(
    particles[connections.x]->pos.x, particles[connections.x]->pos.y,
    particles[connections.y]->pos.x, particles[connections.y]->pos.y
  ) - homeDis;
  if (abs(offset) > durability) {
    connections = sf::Vector2u(-1, -1);
    return;
  }

  auto out = pf::normalize(
    particles[connections.x]->pos.x - particles[connections.y]->pos.x,
    particles[connections.x]->pos.y - particles[connections.y]->pos.y
  );
  sf::Vector2f dir(out[0], out[1]);

  PointMass* pX = (PointMass*)particles[connections.x];
  PointMass* pY = (PointMass*)particles[connections.y];

  sf::Vector2f damped = pX->velocity - pY->velocity * damping;
  float force = offset * stiffness + pf::dotProduct(dir.x, dir.y, damped.x, damped.y);
  pX->addForce(-dir * force);
  pY->addForce(dir * force);
}

void Spring::draw(sf::RenderTarget& SCREEN) {
  if (connections.x == connections.y) return;

  sf::Vector2f pos = particles[connections.x]->pos;
  sf::Vector2f step = (particles[connections.y]->pos - particles[connections.x]->pos) / floorf(homeDis/10);
  int mult = 1;
  float dis = pf::distance(0.0, 0.0, step.x, step.y);
  if (sprite.getVertexCount() > 1) {
    for (int p = 0; p <= floor(homeDis/10); p++) {
      sprite[p].position = pos;
      pos += (step+(sf::Vector2f(step.y*mult, step.x*-mult)/(dis/10)));
      mult = -mult;
    }
    SCREEN.draw(sprite);
  }
}