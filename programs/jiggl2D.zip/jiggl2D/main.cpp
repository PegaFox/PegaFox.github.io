#include <SFML/Graphics.hpp>
#include <iostream>
#include <cmath>
#include <chrono>
#include <fstream>

#include "jiggl2d/jiggl2d.hpp"
#include <pegafox/menu_utils.hpp>

class uiTools {
  public:
    sf::Sprite toolIcon;
    bool particleSelect = false;
    bool springSelect = false;
    bool ropeSelect = false;
    bool colliderSelect = false;
    bool particleVisible = true;
    bool springVisible = true;
    bool ropeVisible = true;
    bool colliderVisible = true;
    
    uiTools() {
      particleIcon.loadFromFile("assets/particleIcon.png");
      springIcon.loadFromFile("assets/springIcon.png");
      ropeIcon.loadFromFile("assets/ropeIcon.png");
      colliderIcon.loadFromFile("assets/colliderIcon.png");
      visible.loadFromFile("assets/visible.png");
      invisible.loadFromFile("assets/invisible.png");

      speedSlider.setCaption("Speed ");
      speedSlider.setFont("../PublicPixel.ttf");
      speedSlider.setRange(sf::Vector2f(0.01f, 10.0f));
    }

    void draw(sf::RenderWindow& SCREEN) {
      // set sizes
      float uiSize = SCREEN.getView().getSize().x/16.0f;

      particleButton.setSize(sf::Vector2f(uiSize, uiSize));
      particleButton.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(0, 0)));
      springButton.setSize(sf::Vector2f(uiSize, uiSize));
      springButton.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(0, 32)));
      ropeButton.setSize(sf::Vector2f(uiSize, uiSize));
      ropeButton.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(0, 64)));
      colliderButton.setSize(sf::Vector2f(uiSize, uiSize));
      colliderButton.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(0, 96)));
      particleToggle.setSize(sf::Vector2f(uiSize, uiSize));
      particleToggle.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(32, 0)));
      springToggle.setSize(sf::Vector2f(uiSize, uiSize));
      springToggle.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(32, 32)));
      ropeToggle.setSize(sf::Vector2f(uiSize, uiSize));
      ropeToggle.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(32, 64)));
      colliderToggle.setSize(sf::Vector2f(uiSize, uiSize));
      colliderToggle.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(32, 96)));

      speedSlider.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(80, 16)));
      speedSlider.setSize(sf::Vector2f(uiSize * 4.0f, uiSize * 0.5f));

      // check for updates
      particleButton.update(SCREEN, SCREEN);
      springButton.update(SCREEN, SCREEN);
      ropeButton.update(SCREEN, SCREEN);
      colliderButton.update(SCREEN, SCREEN);
      particleToggle.update(SCREEN, SCREEN);
      springToggle.update(SCREEN, SCREEN);
      ropeToggle.update(SCREEN, SCREEN);
      colliderToggle.update(SCREEN, SCREEN);

      speedSlider.update(SCREEN, SCREEN);

      float iconScale = uiSize/32;
      toolIcon.setScale(sf::Vector2f(iconScale, iconScale));

      toolIcon.setTexture(particleIcon);
      toolIcon.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(0, 0)));
      SCREEN.draw(toolIcon);
      toolIcon.setTexture(springIcon);
      toolIcon.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(0, 32)));
      SCREEN.draw(toolIcon);
      toolIcon.setTexture(ropeIcon);
      toolIcon.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(0, 64)));
      SCREEN.draw(toolIcon);
      toolIcon.setTexture(colliderIcon);
      toolIcon.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(0, 96)));
      SCREEN.draw(toolIcon);

      if (particleVisible) toolIcon.setTexture(visible);
      else toolIcon.setTexture(invisible);
      toolIcon.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(32, 0)));
      SCREEN.draw(toolIcon);
      if (springVisible) toolIcon.setTexture(visible);
      else toolIcon.setTexture(invisible);
      toolIcon.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(32, 32)));
      SCREEN.draw(toolIcon);
      if (ropeVisible) toolIcon.setTexture(visible);
      else toolIcon.setTexture(invisible);
      toolIcon.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(32, 64)));
      SCREEN.draw(toolIcon);
      if (colliderVisible) toolIcon.setTexture(visible);
      else toolIcon.setTexture(invisible);
      toolIcon.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(32, 96)));
      SCREEN.draw(toolIcon);
    }
  private:
    sf::Texture particleIcon;
    sf::Texture springIcon;
    sf::Texture ropeIcon;
    sf::Texture colliderIcon;
    sf::Texture visible;
    sf::Texture invisible;

    pf::Button particleButton = pf::Button(&particleSelect);
    pf::Button springButton = pf::Button(&springSelect);
    pf::Button ropeButton = pf::Button(&ropeSelect);
    pf::Button colliderButton = pf::Button(&colliderSelect);
    pf::Toggle particleToggle = pf::Toggle(&particleVisible);
    pf::Toggle springToggle = pf::Toggle(&springVisible);
    pf::Toggle ropeToggle = pf::Toggle(&ropeVisible);
    pf::Toggle colliderToggle = pf::Toggle(&colliderVisible);

    pf::Slider<float> speedSlider = pf::Slider<float>(&j2::speed);
} UI;

sf::View cam(sf::FloatRect(0, 0, 512, 512));

enum selection {
  pointMass,
  spring,
  rope,
  collider
};

int selected = pointMass;

void softBox(int width, int height, int size);

int main() {
  pf::FPS fpsClock;
  srand(time(0));
  int held = -1;
  bool pause = true;

  j2::PointMass* fixed = new j2::PointMass(sf::Vector2f(512, 0));
  fixed->fixed = true;
  j2::particles.push_back(fixed);
  fixed = new j2::PointMass(sf::Vector2f(32, 0));
  fixed->fixed = true;
  j2::particles.push_back(fixed);

  softBox(16, 16, 128);
  /*particles.insert(particles.end(), {
    new PointMass(sf::Vector2f(100, 100)),
    new PointMass(sf::Vector2f(200, 100)),
    new PointMass(sf::Vector2f(200, 200)),
    new PointMass(sf::Vector2f(300, 100)),
    new PointMass(sf::Vector2f(300, 200)),
    new PointMass(sf::Vector2f(400, 200))
  });
  connectors.insert(connectors.end(), {
    new Spring(sf::Vector2u(0, 1)),
    new Spring(sf::Vector2u(1, 2)),
    new Spring(sf::Vector2u(2, 0)),
    new Spring(sf::Vector2u(3, 4), 200.0f),
    new Spring(sf::Vector2u(4, 5), 200.0f),
    new Spring(sf::Vector2u(5, 3), 200.0f)
  });
  meshes.insert(meshes.end(), {
    new Collider({0, 1, 2}),
    new Collider({3, 4, 5})
  });*/

  sf::RenderWindow SCREEN(sf::VideoMode(512, 512), "Sandbox");
  SCREEN.setFramerateLimit(60);
  SCREEN.setView(cam);
  while (SCREEN.isOpen()) {
    sf::Event event;
    while (SCREEN.pollEvent(event)) {
      switch (event.type) {
        case sf::Event::Closed: {
          std::vector<j2::Object*> genericList;
          genericList.reserve(j2::particles.size()+j2::connectors.size());
          for (uint32_t p = 0; p < j2::particles.size(); p++)
            genericList.push_back(j2::particles[p]);
          for (uint32_t c = 0; c < j2::connectors.size(); c++)
            genericList.push_back(j2::connectors[c]);

          std::ofstream save("creature.j2d");
          save << j2::exportData(genericList);
          save.close();
          SCREEN.close();
          break;
        } case sf::Event::KeyPressed:
          if (event.key.code == sf::Keyboard::Space) pause = !pause;
          break;
        case sf::Event::MouseButtonPressed: {
          if (event.mouseButton.button == sf::Mouse::Left) {
            sf::Vector2f worldValue = SCREEN.mapPixelToCoords(sf::Vector2i(event.mouseButton.x, event.mouseButton.y));

            for (int p = 0; p < j2::particles.size(); p++)
              if (pf::distance(worldValue.x, worldValue.y, j2::particles[p]->pos.x, j2::particles[p]->pos.y) <= ((j2::PointMass*)j2::particles[p])->mass)
                held = p;
          }
          if (event.mouseButton.button == sf::Mouse::Right) {
            if (selected == pointMass) {
              j2::particles.push_back(new j2::PointMass(SCREEN.mapPixelToCoords(sf::Vector2i(event.mouseButton.x, event.mouseButton.y))));
            } else if (selected < collider) {
              sf::Vector2f worldValue = SCREEN.mapPixelToCoords(sf::Vector2i(event.mouseButton.x, event.mouseButton.y));

              for (int p = 0; p < j2::particles.size(); p++)
                if (pf::distance(worldValue.x, worldValue.y, j2::particles[p]->pos.x, j2::particles[p]->pos.y) <= ((j2::PointMass*)j2::particles[p])->mass) {
                  if (selected == spring) {
                    j2::connectors.push_back(new j2::Spring());
                    held = -2;
                  }
                  if (selected == rope) {
                    j2::connectors.push_back(new j2::Rope());
                    held = -4;
                  }
                  j2::connectors.back()->connections.x = p;
                  j2::connectors.back()->connections.y = p;
              }
            } else {
              sf::Vector2f worldValue = SCREEN.mapPixelToCoords(sf::Vector2i(event.mouseButton.x, event.mouseButton.y));

              for (int p = 0; p < j2::particles.size(); p++)
                if (pf::distance(worldValue.x, worldValue.y, j2::particles[p]->pos.x, j2::particles[p]->pos.y) <= ((j2::PointMass*)j2::particles[p])->mass) {
                  j2::meshes.push_back(new j2::Collider());
                  held = -3;
                  j2::meshes.back()->vertices.push_back(p);
                }
            }
          }
          break;
        }
        case sf::Event::MouseButtonReleased:
          held = -1;
          break;
        case sf::Event::MouseWheelMoved:
          cam.zoom(0.9f - (float)event.mouseWheel.delta*0.2f);
          SCREEN.setView(cam);
      }
    }

    if (UI.particleSelect) {
      selected = pointMass;
    }
    if (UI.springSelect) {
      selected = spring;
    }
    if (UI.ropeSelect) {
      selected = rope;
    }
    if (UI.colliderSelect) {
      selected = collider;
    }

    if (sf::Keyboard::isKeyPressed(sf::Keyboard::W) || sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
      cam.move(sf::Vector2f(0.0f, -0.01f*cam.getSize().y));
      SCREEN.setView(cam);
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::S) || sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
      cam.move(sf::Vector2f(0.0f, 0.01f*cam.getSize().y));
      SCREEN.setView(cam);
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::A) || sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
      cam.move(sf::Vector2f(-0.01f*cam.getSize().x, 0.0f));
      SCREEN.setView(cam);
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::D) || sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
      cam.move(sf::Vector2f(0.01f*cam.getSize().x, 0.0f));
      SCREEN.setView(cam);
    }
    
    if ((held == -2 || held == -4) && selected >= spring && selected <= rope && sf::Mouse::isButtonPressed(sf::Mouse::Right)) {
      sf::Vector2f mPos(SCREEN.mapPixelToCoords(sf::Mouse::getPosition(SCREEN)));
      for (int p = 0; p < j2::particles.size(); p++) {
        if (j2::connectors.back()->connections.x != p && pf::distance(mPos.x, mPos.y, j2::particles[p]->pos.x, j2::particles[p]->pos.y) <= ((j2::PointMass*)j2::particles[p])->mass) {
          if (held == -2) {
            ((j2::Spring*)j2::connectors.back())->setHomeDis(pf::distance(
              j2::particles[j2::connectors.back()->connections.x]->pos.x, j2::particles[j2::connectors.back()->connections.x]->pos.y,
              j2::particles[j2::connectors.back()->connections.y]->pos.x, j2::particles[j2::connectors.back()->connections.y]->pos.y
            ));
          } else {
            ((j2::Rope*)j2::connectors.back())->homeDis = pf::distance(
              j2::particles[j2::connectors.back()->connections.x]->pos.x, j2::particles[j2::connectors.back()->connections.x]->pos.y,
              j2::particles[j2::connectors.back()->connections.y]->pos.x, j2::particles[j2::connectors.back()->connections.y]->pos.y
            );
          }
          j2::connectors.back()->connections.y = p;
        }
      }
    }

    if (held == -3 && selected >= collider && sf::Mouse::isButtonPressed(sf::Mouse::Right)) {
      sf::Vector2f mPos(SCREEN.mapPixelToCoords(sf::Mouse::getPosition(SCREEN)));
      for (int p = 0; p < j2::particles.size(); p++) 
        if (j2::meshes.back()->vertices.back() != p && pf::distance(mPos.x, mPos.y, j2::particles[p]->pos.x, j2::particles[p]->pos.y) <= ((j2::PointMass*)j2::particles[p])->mass) {
          j2::meshes.back()->vertices.push_back(p);
        }
    }

    if (pause) {
      
    } else {
      if (sf::Keyboard::isKeyPressed(sf::Keyboard::Equal)) {
        for (uint32_t s = 0; s < j2::connectors.size(); s++) {
          j2::Spring* spring = dynamic_cast<j2::Spring*>(j2::connectors[s]);
          if (spring == nullptr) continue;
          spring->stiffness += 0.01f;

          if (s == 0) std::cout << "Stiffness " << spring->stiffness << '\n';
        }
      }
      if (sf::Keyboard::isKeyPressed(sf::Keyboard::Dash)) {
        for (uint32_t s = 0; s < j2::connectors.size(); s++) {
          j2::Spring* spring = dynamic_cast<j2::Spring*>(j2::connectors[s]);
          if (spring == nullptr) continue;
          spring->stiffness -= 0.01f;

          if (s == 0) std::cout << "Stiffness " << spring->stiffness << '\n';
        }
      }

      for (int c = 0; c < j2::connectors.size(); c++) {
        j2::connectors[c]->update();
      }

      for (int p = 0; p < j2::particles.size(); p++) {
        j2::PointMass* particle = (j2::PointMass*)j2::particles[p];
        particle->addForce(sf::Vector2f(0.0f, 0.1f * particle->mass));
        if (particle->pos.y + particle->velocity.y*j2::speed > 512.0f) {
          j2::particles[p]->pos.y = 512;

          auto bounceDir = pf::reflect(particle->velocity.x, particle->velocity.y, 0.0f, -1.0f);
          particle->velocity = sf::Vector2f(bounceDir[0], bounceDir[1])*particle->bounciness;
        }
        particle->update();
      }

      for (int m = 0; m < j2::meshes.size(); m++)
        ((j2::Collider*)j2::meshes[m])->update();
    }

    if (held > -1) {
      sf::Vector2f mPos(SCREEN.mapPixelToCoords(sf::Mouse::getPosition(SCREEN)));
      if (pause)
        j2::particles[held]->pos = mPos;
      else
        ((j2::PointMass*)j2::particles[held])->velocity = sf::Vector2f(mPos-j2::particles[held]->pos);
    }
    SCREEN.clear();

    if (UI.particleVisible)
      for (int p = 0; p < j2::particles.size(); p++)
        j2::particles[p]->draw(SCREEN);

    for (int c = 0; c < j2::connectors.size(); c++) {
      j2::Spring* compare = dynamic_cast<j2::Spring*>(j2::connectors[c]);
      if (UI.springVisible && compare != nullptr) {
        j2::connectors[c]->draw(SCREEN);
      } else if (UI.ropeVisible && compare == nullptr) {
        j2::connectors[c]->draw(SCREEN);
      }
    }

    if (UI.colliderVisible)
      for (int m = 0; m < j2::meshes.size(); m++)
        j2::meshes[m]->draw(SCREEN);

    if (pause) {
      UI.draw(SCREEN);
    }
    
    SCREEN.display();

    SCREEN.setTitle("fps: "+std::to_string(int(fpsClock.get_fps())));
  }
  return 0;
}

void softBox(int width, int height, int size) {
  for (int y = 0; y < height; y++) {// note: x and y cannot be uints
    for (int x = 0; x < width; x++) {
      j2::particles.push_back(new j2::PointMass(sf::Vector2f(x*size+(y % 2), 512-(y*size)), 10.0f));

      if (x > 0) {
        j2::connectors.push_back(new j2::Spring(size));
        j2::connectors.back()->connections.x = j2::particles.size()-1;
        j2::connectors.back()->connections.y = j2::particles.size()-2;
      }
      if (y > 0) {
        j2::connectors.push_back(new j2::Spring(size));
        j2::connectors.back()->connections.x = j2::particles.size()-1;
        j2::connectors.back()->connections.y = j2::particles.size()-(width+1);
      }
      if (x > 0 && y > 0) {
        j2::connectors.push_back(new j2::Spring(pf::distance(j2::particles.back()->pos.x, j2::particles.back()->pos.y, j2::particles[j2::particles.size()-(width+2)]->pos.x, j2::particles[j2::particles.size()-(width+2)]->pos.y)));
        j2::connectors.back()->connections.x = j2::particles.size()-1;
        j2::connectors.back()->connections.y = j2::particles.size()-(width+2);
      }
      if (x < (width-1) && y > 0) {
        j2::connectors.push_back(new j2::Spring(pf::distance(j2::particles.back()->pos.x, j2::particles.back()->pos.y, j2::particles[j2::particles.size()-width]->pos.x, j2::particles[j2::particles.size()-width]->pos.y)));
        j2::connectors.back()->connections.x = j2::particles.size()-1;
        j2::connectors.back()->connections.y = j2::particles.size()-width;
      }
      /*if (x+y > 0) {
        j2::connectors.push_back(new j2::Rope(size));
        j2::connectors.back()->connections.x = j2::particles.size()-1;
        j2::connectors.back()->connections.y = j2::particles.size()-2;
      }*/
    }
  }

  j2::Collider* boxCollider = new j2::Collider;
  for (uint x = 0; x < width-1; x++)
    //std::cout << "top\n";
    boxCollider->vertices.push_back(x+2);
  for (uint y = width-1; y < width*height; y += width)
    //std::cout << "right\n";
    boxCollider->vertices.push_back(y+2);
  for (uint x = width*height - 2; x > width * (height-1); x--)
    //std::cout << "bottom\n";
    boxCollider->vertices.push_back(x+2);
  for (uint y = width * (height-1); y > 0; y -= width)
    //std::cout << "left\n";
    boxCollider->vertices.push_back(y+2);
  j2::meshes.push_back(boxCollider);

}

#include "jiggl2d/jiggl2d_cleanup.hpp"