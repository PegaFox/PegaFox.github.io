jiggl2D - a softbody physics sandbox
controls:
space - pause/unpause
right click - create object. To create a rope, spring, or mesh, right click and drag between particles
left click - move particles


this project depends on sfml
to build, compile main.cpp and link sfml

features:
point masses
springs
ropes - incomplete
collision meshes - incomplete

updates
todo:
  add a moving camera
  upgrade the UI
  add a collision mesh

completed:
  allow showing/hiding certain elements
  give objects durability
