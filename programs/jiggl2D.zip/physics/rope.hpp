class Rope {
  public:
    sf::Vector2u connections;
    float homeDis;

    Rope() {
      sprite.setPrimitiveType(sf::Lines);
      sprite.resize(2);
    }

    Rope(float newMaxDis) {
      homeDis = newMaxDis;

      sprite.setPrimitiveType(sf::Lines);
      sprite.resize(2);
    }

    void update() {
      float offset = distance(particles[connections.x].pos, particles[connections.y].pos) - homeDis;
      if (offset <= 0) return;
      sf::Vector2f dir = particles[connections.x].pos - particles[connections.y].pos;
      float dis = distance(sf::Vector2f(), dir);
      if (dis != 0.0f)
        dir /= dis;
      else
        dir = sf::Vector2f(0, 0);
      particles[connections.x].addForce(-dir * offset);
      particles[connections.y].addForce(dir * offset);
    }

    void draw(sf::RenderTarget& SCREEN) {
      sprite[0].position = particles[connections.x].pos;
      sprite[1].position = particles[connections.y].pos;
      SCREEN.draw(sprite);
    }
  private:
    sf::VertexArray sprite;
};