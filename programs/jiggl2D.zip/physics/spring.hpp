class Spring {
  public:
    sf::Vector2u connections;
    float stiffness = 1.0f;
    float damping = 1.0f;

    Spring() {
      setHomeDis(100);
      sprite.setPrimitiveType(sf::LineStrip);
    }

    Spring(float newHomeDis) {
      setHomeDis(newHomeDis);
      sprite.setPrimitiveType(sf::LineStrip);
    }

    void setHomeDis(float newHomeDis) {
      homeDis = newHomeDis;
      sprite.resize(floor(homeDis/10)+1);
    }

    float getHomeDis() {
      return homeDis;
    }

    void update() {
      float offset = distance(particles[connections.x].pos, particles[connections.y].pos) - homeDis;
      sf::Vector2f dir = particles[connections.x].pos - particles[connections.y].pos;
      float dis = distance(sf::Vector2f(), dir);
      if (dis != 0.0f)
        dir /= dis;
      else
        dir = sf::Vector2f(0, 0);
      float force = offset * stiffness + dotProduct(dir, particles[connections.x].velocity - particles[connections.y].velocity) * damping;
      particles[connections.x].addForce(-dir * force);
      particles[connections.y].addForce(dir * force);
    }

    void draw(sf::RenderTarget& SCREEN) {
      sf::Vector2f pos = particles[connections.x].pos;
      sf::Vector2f step = (particles[connections.y].pos - particles[connections.x].pos) / floorf(homeDis/10);
      int mult = 1;
      float dis = distance(sf::Vector2f(), step);
      if (sprite.getVertexCount() > 1) {
        for (int p = 0; p <= floor(homeDis/10); p++) {
          sprite[p].position = pos;
          pos += (step+(sf::Vector2f(step.y*mult, step.x*-mult)/(dis/10)));
          mult = -mult;
        }
        SCREEN.draw(sprite);
      }
    }

  private:
    sf::VertexArray sprite;
    float homeDis;
};