class Particle {
  public:
    sf::Vector2f pos;
    sf::Vector2f velocity;
    float bounciness = 0.1f;
    float collisionRadius = 0.0f;

    Particle() {
      setMass(10.0f);
      sprite.setOutlineThickness(1.0f);
    }

    Particle(const sf::Vector2f& newPos, float mass = 10.0f, float collisionRadius = 0.0f) {
      pos = newPos;
      setMass(mass);
      this->collisionRadius = collisionRadius;
      sprite.setOutlineThickness(1.0f);
    }

    float getMass() {
      return mass;
    }

    void setMass(float mass) {
      this->mass = mass;
    }

    void addForce(sf::Vector2f force) {
      force /= mass;
      force *= 0.8f;
      velocity += force;
    }

    void update(std::vector<Particle>& particles) {
      

      for (int p = 0; p < particles.size(); p++) {
        float dis = distance(pos, particles[p].pos);
        if (dis > 0 && dis < collisionRadius+particles[p].collisionRadius) {
          sf::Vector2f ang(pos - particles[p].pos);
          ang /= dis;
          velocity += ang*((collisionRadius+particles[p].collisionRadius)-dis);
        }
      }

      pos += velocity;
    }

    void draw(sf::RenderTarget& SCREEN) {
      sprite.setFillColor(sf::Color::White);
      sprite.setRadius(mass);
      sprite.setOrigin(sf::Vector2f(mass, mass));
      sprite.setPosition(pos);
      SCREEN.draw(sprite);
      sprite.setFillColor(sf::Color::Transparent);
      sprite.setRadius(collisionRadius);
      sprite.setOrigin(sf::Vector2f(collisionRadius, collisionRadius));
      SCREEN.draw(sprite);
    }

  private:
    sf::CircleShape sprite;
    float mass;
};