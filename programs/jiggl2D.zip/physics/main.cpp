#include <SFML/Graphics.hpp>
#include <iostream>
#include <cmath>

#include "util_funcs.hpp"

#include "particle.hpp"

std::vector<Particle> particles;

#include "spring.hpp"
#include "rope.hpp"

std::vector<Spring> springs;
std::vector<Rope> ropes;

#include "collider.hpp"

std::vector<Collider> colliders;

enum selection {
  particle,
  spring,
  rope,
  collider
};

int selected = spring;

int main() {
  FPS fpsClock;
  srand(time(0));
  int held = -1;
  bool pause = false;

  int width = 4;
  int height = 4;
  int size = 128;
  for (int y = 0; y < height; y++)
    for (int x = 0; x < width; x++) {
      particles.push_back(Particle(sf::Vector2f(x*size+(y % 2), -y*size), 10.0f));
      if (x > 0) {
        springs.push_back(Spring(size));
        springs.back().connections.x = particles.size()-1;
        springs.back().connections.y = particles.size()-2;
      }
      if (y > 0) {
        springs.push_back(Spring(size));
        springs.back().connections.x = particles.size()-1;
        springs.back().connections.y = particles.size()-(width+1);
      }
      if (x > 0 && y > 0) {
        springs.push_back(Spring(distance(particles.back().pos, particles[particles.size()-(width+2)].pos)));
        springs.back().connections.x = particles.size()-1;
        springs.back().connections.y = particles.size()-(width+2);
      }
      if (x < (width-1) && y > 0) {
        springs.push_back(Spring(distance(particles.back().pos, particles[particles.size()-width].pos)));
        springs.back().connections.x = particles.size()-1;
        springs.back().connections.y = particles.size()-width;
      }
    }

  sf::Texture particleIcon;
  particleIcon.loadFromFile("assets/particleIcon.png");
  sf::Texture springIcon;
  springIcon.loadFromFile("assets/springIcon.png");
  sf::Texture ropeIcon;
  ropeIcon.loadFromFile("assets/ropeIcon.png");
  sf::Texture colliderIcon;
  colliderIcon.loadFromFile("assets/colliderIcon.png");
  sf::Texture visible;
  visible.loadFromFile("assets/visible.png");
  sf::Texture invisible;
  invisible.loadFromFile("assets/invisible.png");

  sf::Sprite toolIcon;

  bool particleSelect = false;
  Button particleButton(&particleSelect);
  particleButton.setSize(sf::Vector2f(32.0f, 32.0f));
  particleButton.setPosition(sf::Vector2f(0.0f, 0.0f));

  bool springSelect = false;
  Button springButton(&springSelect);
  springButton.setSize(sf::Vector2f(32.0f, 32.0f));
  springButton.setPosition(sf::Vector2f(0.0f, 32.0f));

  bool ropeSelect = false;
  Button ropeButton(&ropeSelect);
  ropeButton.setSize(sf::Vector2f(32.0f, 32.0f));
  ropeButton.setPosition(sf::Vector2f(0.0f, 64.0f));

  bool colliderSelect = false;
  Button colliderButton(&colliderSelect);
  colliderButton.setSize(sf::Vector2f(32.0f, 32.0f));
  colliderButton.setPosition(sf::Vector2f(0.0f, 96.0f));

  bool particleVisible = true;
  Toggle particleToggle(&particleVisible);
  particleToggle.setSize(sf::Vector2f(32.0f, 32.0f));
  particleToggle.setPosition(sf::Vector2f(32.0f, 0.0f));

  bool springVisible = true;
  Toggle springToggle(&springVisible);
  springToggle.setSize(sf::Vector2f(32.0f, 32.0f));
  springToggle.setPosition(sf::Vector2f(32.0f, 32.0f));

  bool ropeVisible = true;
  Toggle ropeToggle(&ropeVisible);
  ropeToggle.setSize(sf::Vector2f(32.0f, 32.0f));
  ropeToggle.setPosition(sf::Vector2f(32.0f, 64.0f));

  bool colliderVisible = true;
  Toggle colliderToggle(&colliderVisible);
  colliderToggle.setSize(sf::Vector2f(32.0f, 32.0f));
  colliderToggle.setPosition(sf::Vector2f(32.0f, 96.0f));

  sf::RenderWindow SCREEN(sf::VideoMode(512, 512), "Sandbox");
  sf::View camera(sf::FloatRect(0, 0, 512, 512));
  SCREEN.setView(camera);
  SCREEN.setFramerateLimit(60);
  while (SCREEN.isOpen()) {
    sf::Event event;
    while (SCREEN.pollEvent(event)) {
      switch (event.type) {
        case sf::Event::Closed:
          SCREEN.close();
          break;
        case sf::Event::KeyPressed:
          if (event.key.code == sf::Keyboard::Space) pause = !pause;
          break;
        case sf::Event::MouseButtonPressed: {
          if (event.mouseButton.button == sf::Mouse::Left)
            for (int p = 0; p < particles.size(); p++) 
              if (distance(sf::Vector2f(event.mouseButton.x, event.mouseButton.y), particles[p].pos) <= particles[p].getMass())
                held = p;
          if (event.mouseButton.button == sf::Mouse::Right) {
            if (selected == particle) {
              particles.push_back(Particle(sf::Vector2f(event.mouseButton.x, event.mouseButton.y)));
            } else if (selected < collider) {
              for (int p = 0; p < particles.size(); p++)
                if (distance(sf::Vector2f(event.mouseButton.x, event.mouseButton.y), particles[p].pos) <= particles[p].getMass()) {
                  if (selected == spring) {
                    springs.push_back(Spring());
                    springs.back().connections.x = p;
                    springs.back().connections.y = p;
                    held = -2;
                  }
                  if (selected == rope) {
                    ropes.push_back(Rope());
                    ropes.back().connections.x = p;
                    ropes.back().connections.y = p;
                    held = -4;
                  }
              }
            } else {
              for (int p = 0; p < particles.size(); p++)
                if (distance(sf::Vector2f(event.mouseButton.x, event.mouseButton.y), particles[p].pos) <= particles[p].getMass()) {
                  colliders.push_back(Collider());
                  held = -3;
                  colliders.back().vertices.push_back(p);
                }
            }
          }
          break;
        }
        case sf::Event::MouseButtonReleased:
          held = -1;
          break;
        case sf::Event::MouseWheelMoved:
          if (held > -1)
            particles[held].setMass(particles[held].getMass()+event.mouseWheel.delta);
          else
            camera.zoom(1.0f - event.mouseWheel.delta * 0.1f);
          break;
      }
    }

    if (particleSelect) {
      selected = particle;
    }
    if (springSelect) {
      selected = spring;
    }
    if (ropeSelect) {
      selected = rope;
    }
    if (colliderSelect) {
      selected = collider;
    }

    /*if (sf::Keyboard::isKeyPressed(sf::Keyboard::W) || sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
      camera.move(sf::Vector2f(0.0f, -1.0f));
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::S) || sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
      camera.move(sf::Vector2f(0.0f, 1.0f));
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::A) || sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
      camera.move(sf::Vector2f(-1.0f, 0.0f));
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::D) || sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
      camera.move(sf::Vector2f(1.0f, 0.0f));
    }
    SCREEN.setView(camera);*/
    
    if ((held == -2 || held == -4) && selected >= spring && selected <= rope && sf::Mouse::isButtonPressed(sf::Mouse::Right)) {
      sf::Vector2i mPos(sf::Mouse::getPosition(SCREEN));
      for (int p = 0; p < particles.size(); p++) {
        if (held == -2 && springs.back().connections.x != p && distance(sf::Vector2f(mPos), particles[p].pos) <= particles[p].getMass()) {
          springs.back().connections.y = p;
          springs.back().setHomeDis(distance(
            particles[springs.back().connections.x].pos, 
            particles[springs.back().connections.y].pos
          ));
        }
        if (held == -4 && ropes.back().connections.x != p && distance(sf::Vector2f(mPos), particles[p].pos) <= particles[p].getMass()) {
          ropes.back().connections.y = p;
          ropes.back().homeDis = distance(
            particles[ropes.back().connections.x].pos, 
            particles[ropes.back().connections.y].pos
          );
        }
      }
    }

    if (held == -3 && selected >= collider && sf::Mouse::isButtonPressed(sf::Mouse::Right)) {
      sf::Vector2i mPos(sf::Mouse::getPosition(SCREEN));
      for (int p = 0; p < particles.size(); p++) 
        if (colliders.back().vertices.back() != p && distance(sf::Vector2f(mPos), particles[p].pos) <= particles[p].getMass()) {
          colliders.back().vertices.push_back(p);
        }
    }

    if (pause) {
      
    } else {
      for (int s = 0; s < springs.size(); s++) {
        springs[s].update();
      }

      for (int r = 0; r < ropes.size(); r++) {
        ropes[r].update();
      }

      for (int p = 0; p < particles.size(); p++) {
        particles[p].velocity.y += 0.1f;
        if (particles[p].pos.y > 512 && particles[p].velocity.y > 0.0f) {
          particles[p].pos.y = 512;
          particles[p].velocity = -particles[p].velocity*particles[p].bounciness;
        }
        particles[p].update(particles);
      }

      for (int f = 0; f < colliders.size(); f++)
        colliders[f].update(colliders);
    }

    if (held > -1) {
      sf::Vector2i mPos(sf::Mouse::getPosition(SCREEN));
      if (pause)
        particles[held].pos = sf::Vector2f(mPos.x, mPos.y);
      else
        particles[held].velocity = sf::Vector2f(sf::Vector2f(mPos.x, mPos.y)-particles[held].pos);
    }
    SCREEN.clear();

    if (particleVisible)
      for (int p = 0; p < particles.size(); p++)
        particles[p].draw(SCREEN);

    if (springVisible)
      for (int s = 0; s < springs.size(); s++)
        springs[s].draw(SCREEN);

    if (ropeVisible)
      for (int r = 0; r < ropes.size(); r++)
        ropes[r].draw(SCREEN);

    if (colliderVisible)
      for (int f = 0; f < colliders.size(); f++)
        colliders[f].draw(SCREEN);

    if (pause) {
      particleButton.update(SCREEN, SCREEN);
      springButton.update(SCREEN, SCREEN);
      ropeButton.update(SCREEN, SCREEN);
      colliderButton.update(SCREEN, SCREEN);
      particleToggle.update(SCREEN, SCREEN);
      springToggle.update(SCREEN, SCREEN);
      ropeToggle.update(SCREEN, SCREEN);
      colliderToggle.update(SCREEN, SCREEN);

      toolIcon.setTexture(particleIcon);
      toolIcon.setPosition(sf::Vector2f(0.0f, 0.0f));
      SCREEN.draw(toolIcon);
      toolIcon.setTexture(springIcon);
      toolIcon.setPosition(sf::Vector2f(0.0f, 32.0f));
      SCREEN.draw(toolIcon);
      toolIcon.setTexture(ropeIcon);
      toolIcon.setPosition(sf::Vector2f(0.0f, 64.0f));
      SCREEN.draw(toolIcon);
      toolIcon.setTexture(colliderIcon);
      toolIcon.setPosition(sf::Vector2f(0.0f, 96.0f));
      SCREEN.draw(toolIcon);

      if (particleVisible) toolIcon.setTexture(visible);
      else toolIcon.setTexture(invisible);
      toolIcon.setPosition(sf::Vector2f(32.0f, 0.0f));
      SCREEN.draw(toolIcon);
      if (springVisible) toolIcon.setTexture(visible);
      else toolIcon.setTexture(invisible);
      toolIcon.setPosition(sf::Vector2f(32.0f, 32.0f));
      SCREEN.draw(toolIcon);
      if (ropeVisible) toolIcon.setTexture(visible);
      else toolIcon.setTexture(invisible);
      toolIcon.setPosition(sf::Vector2f(32.0f, 64.0f));
      SCREEN.draw(toolIcon);
      if (colliderVisible) toolIcon.setTexture(visible);
      else toolIcon.setTexture(invisible);
      toolIcon.setPosition(sf::Vector2f(32.0f, 96.0f));
      SCREEN.draw(toolIcon);
    }
    
    SCREEN.display();

    SCREEN.setTitle("fps: "+std::to_string(int(fpsClock.get_fps())));
  }
  return 0;
}
