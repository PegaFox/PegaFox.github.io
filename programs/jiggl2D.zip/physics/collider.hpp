class Collider {
  public:
    std::vector<unsigned int> vertices;
    sf::FloatRect bounds;

    Collider() {
      sprite.setFillColor(sf::Color(255, 255, 255, 128));
    }

    void update(const std::vector<Collider>& colliders) {
      sf::Vector2f lowest(1000000000000000000.0f, 1000000000000000000.0f);
      sf::Vector2f highest(-1000000000000000000.0f, -1000000000000000000.0f);
      for (int point = 0; point < vertices.size(); point++) {
        if (particles[vertices[point]].pos.x < lowest.x)
          lowest.x = particles[vertices[point]].pos.x;
        if (particles[vertices[point]].pos.y < lowest.y)
          lowest.y = particles[vertices[point]].pos.y;
        if (particles[vertices[point]].pos.x > highest.x)
          highest.x = particles[vertices[point]].pos.x;
        if (particles[vertices[point]].pos.y > highest.y)
          highest.y = particles[vertices[point]].pos.y;
      }

      bounds = sf::FloatRect(lowest, highest-lowest);
      for (int obj = 0; obj < colliders.size(); obj++) {
        if (colliders[obj].bounds == bounds) continue;
        if (bounds.intersects(colliders[obj].bounds))
          for (int point = 0; point < colliders[obj].vertices.size(); point++) {
            float ray = particles[colliders[obj].vertices[point]].pos.y;
            for (int line = 0; line < vertices.size(); line++) {}
          }
      }
    }

    void draw(sf::RenderTarget& SCREEN) {
      sprite.setPointCount(vertices.size());
      for (int point = 0; point < vertices.size(); point++) {
        sprite.setPoint(point, particles[vertices[point]].pos);
      }
      SCREEN.draw(sprite);
    }
  private:
    sf::ConvexShape sprite;
};