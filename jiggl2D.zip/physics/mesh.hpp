class Mesh : public Object {
  public:
    std::vector<unsigned int> vertices;
};