class Collider : public Mesh {
  public:
    sf::FloatRect bounds;

    Collider() {
      sprite.setFillColor(sf::Color(255, 255, 255, 128));
      sprite.setPointCount(4);
    }

    Collider(const std::vector<unsigned int>& vertices) {
      this->vertices = vertices;
      sprite.setFillColor(sf::Color(255, 255, 255, 128));
      sprite.setPointCount(4);
    }

    void update(const std::vector<Mesh*>& meshes) {
      if (sprite.getFillColor() == sf::Color::Red) sprite.setFillColor(sf::Color(255, 255, 255, 128));

      bounds = sprite.getGlobalBounds();
      for (int obj = 0; obj < meshes.size(); obj++) {
        if (((Collider*)meshes[obj])->bounds == bounds) continue;
        if (bounds.intersects(((Collider*)meshes[obj])->bounds)) {
          for (int point = 0; point < meshes[obj]->vertices.size(); point++) {
            PointMass* testPoint = (PointMass*)particles[meshes[obj]->vertices[point]];
            uint32_t total = 0;
            std::vector<sf::Vector2f> closePts;
            for (int line = 0; line < vertices.size(); line++) {
              sf::Vector2f* lineVert1 = &particles[vertices[line]]->pos;
              sf::Vector2f* lineVert2 = &particles[vertices[(line+1)%vertices.size()]]->pos;
              
              sf::Vector2f hit = rayCollide(testPoint->pos, *lineVert1, *lineVert2);

              if (hit == hit) {
                total++;
                closePts.push_back(hit);
              }
            }
            std::cout << '\n';
            if (total % 2 == 1) {
              std::cout << "COLLIDE\n";
              float lowDis = 1000000000000000000.0f;
              uint32_t lowInd = 0;
              for (uint32_t p = 0; p < closePts.size(); p++) {
                float dis = distance(testPoint->pos, closePts[p]);
                if (dis < lowDis) {
                  lowDis = dis;
                  lowInd = p;
                }
              }

              testPoint->velocity = reflect(testPoint->velocity, normalize(testPoint->pos-closePts[lowInd]));
              testPoint->pos = closePts[lowInd];
            }
          }
        }
      }
    }

    void draw(sf::RenderTarget& SCREEN) {
      sprite.setPointCount(vertices.size());
      for (int point = 0; point < vertices.size(); point++) {
        sprite.setPoint(point, particles[vertices[point]]->pos);
      }
      SCREEN.draw(sprite);
    }
  private:
    sf::ConvexShape sprite;

    // checks if point is in object. If so, returns where to move the point to push it out. Otherwise returns nan
    sf::Vector2f rayCollide(const sf::Vector2f& rayOrigin, sf::Vector2f lineStart, sf::Vector2f lineEnd) {
      bool gtStart = rayOrigin.y > lineStart.y;
      bool gtEnd = rayOrigin.y > lineEnd.y;
      std::cout << rayOrigin.y << ", " << lineStart.y << ",  " << lineEnd.y << '\n';
      std::cout << "not high & not low: ";
      if (gtStart != gtEnd) { // not too high and not too low
        std::cout << "1, not right: ";
        if (!(gtStart && gtEnd)) { // not too far right
          std::cout << "1, ";
          float xVal = lineStart.x + (rayOrigin.y-lineStart.y) / (lineEnd.y-lineStart.y) * (lineEnd.x-lineStart.x);
          if (!(gtStart || gtEnd)) {
            std::cout << "left: 1\n";
            return sf::Vector2f((lineStart+lineEnd)/2.0f);
          }
          if (rayOrigin.x < xVal) {
            std::cout << "left in line: 1\n";
            return sf::Vector2f((lineStart+lineEnd)/2.0f);
          }
        } else {
          std::cout << "0\n";
        }
      } else {
        std::cout << "0\n";
      }
      return sf::Vector2f(nanf(""), nanf(""));
    }
};