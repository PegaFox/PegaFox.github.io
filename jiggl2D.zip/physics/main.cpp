#include <SFML/Graphics.hpp>
#include <iostream>
#include <cmath>

#include "util_funcs.hpp"

class uiTools {
  public:
    sf::Sprite toolIcon;
    bool particleSelect = false;
    bool springSelect = false;
    bool ropeSelect = false;
    bool colliderSelect = false;
    bool particleVisible = true;
    bool springVisible = true;
    bool ropeVisible = true;
    bool colliderVisible = true;

    uiTools() {
      particleIcon.loadFromFile("assets/particleIcon.png");
      springIcon.loadFromFile("assets/springIcon.png");
      ropeIcon.loadFromFile("assets/ropeIcon.png");
      colliderIcon.loadFromFile("assets/colliderIcon.png");
      visible.loadFromFile("assets/visible.png");
      invisible.loadFromFile("assets/invisible.png");
    }

    void draw(sf::RenderWindow& SCREEN) {
      // set sizes
      float uiSize = SCREEN.getView().getSize().x/16;

      particleButton.setSize(sf::Vector2f(uiSize, uiSize));
      particleButton.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(0, 0)));
      springButton.setSize(sf::Vector2f(uiSize, uiSize));
      springButton.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(0, 32)));
      ropeButton.setSize(sf::Vector2f(uiSize, uiSize));
      ropeButton.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(0, 64)));
      colliderButton.setSize(sf::Vector2f(uiSize, uiSize));
      colliderButton.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(0, 96)));
      particleToggle.setSize(sf::Vector2f(uiSize, uiSize));
      particleToggle.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(32, 0)));
      springToggle.setSize(sf::Vector2f(uiSize, uiSize));
      springToggle.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(32, 32)));
      ropeToggle.setSize(sf::Vector2f(uiSize, uiSize));
      ropeToggle.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(32, 64)));
      colliderToggle.setSize(sf::Vector2f(uiSize, uiSize));
      colliderToggle.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(32, 96)));

      // check for updates
      particleButton.update(SCREEN, SCREEN);
      springButton.update(SCREEN, SCREEN);
      ropeButton.update(SCREEN, SCREEN);
      colliderButton.update(SCREEN, SCREEN);
      particleToggle.update(SCREEN, SCREEN);
      springToggle.update(SCREEN, SCREEN);
      ropeToggle.update(SCREEN, SCREEN);
      colliderToggle.update(SCREEN, SCREEN);

      float iconScale = uiSize/32;
      toolIcon.setScale(sf::Vector2f(iconScale, iconScale));

      toolIcon.setTexture(particleIcon);
      toolIcon.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(0, 0)));
      SCREEN.draw(toolIcon);
      toolIcon.setTexture(springIcon);
      toolIcon.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(0, 32)));
      SCREEN.draw(toolIcon);
      toolIcon.setTexture(ropeIcon);
      toolIcon.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(0, 64)));
      SCREEN.draw(toolIcon);
      toolIcon.setTexture(colliderIcon);
      toolIcon.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(0, 96)));
      SCREEN.draw(toolIcon);

      if (particleVisible) toolIcon.setTexture(visible);
      else toolIcon.setTexture(invisible);
      toolIcon.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(32, 0)));
      SCREEN.draw(toolIcon);
      if (springVisible) toolIcon.setTexture(visible);
      else toolIcon.setTexture(invisible);
      toolIcon.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(32, 32)));
      SCREEN.draw(toolIcon);
      if (ropeVisible) toolIcon.setTexture(visible);
      else toolIcon.setTexture(invisible);
      toolIcon.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(32, 64)));
      SCREEN.draw(toolIcon);
      if (colliderVisible) toolIcon.setTexture(visible);
      else toolIcon.setTexture(invisible);
      toolIcon.setPosition(SCREEN.mapPixelToCoords(sf::Vector2i(32, 96)));
      SCREEN.draw(toolIcon);
    }
  private:
    sf::Texture particleIcon;
    sf::Texture springIcon;
    sf::Texture ropeIcon;
    sf::Texture colliderIcon;
    sf::Texture visible;
    sf::Texture invisible;

    Button particleButton = Button(&particleSelect);
    Button springButton = Button(&springSelect);
    Button ropeButton = Button(&ropeSelect);
    Button colliderButton = Button(&colliderSelect);
    Toggle particleToggle = Toggle(&particleVisible);
    Toggle springToggle = Toggle(&springVisible);
    Toggle ropeToggle = Toggle(&ropeVisible);
    Toggle colliderToggle = Toggle(&colliderVisible);
} UI;

sf::View cam(sf::FloatRect(0, 0, 512, 512));

#include "object.hpp"

#include "particle.hpp"

#include "pointMass.hpp"

std::vector<Particle*> particles;

#include "connector.hpp"

#include "spring.hpp"
#include "rope.hpp"

std::vector<Connector*> connectors;

#include "mesh.hpp"

#include "collider.hpp"

std::vector<Mesh*> meshes;

enum selection {
  pointMass,
  spring,
  rope,
  collider
};

int selected = pointMass;

void softBox(int width, int height, int size);

int main() {
  FPS fpsClock;
  srand(time(0));
  int held = -1;
  bool pause = false;


  softBox(16, 16, 128);
  /*particles.insert(particles.end(), {
    new PointMass(sf::Vector2f(100, 100)),
    new PointMass(sf::Vector2f(200, 100)),
    new PointMass(sf::Vector2f(200, 200)),
    new PointMass(sf::Vector2f(300, 100)),
    new PointMass(sf::Vector2f(300, 200)),
    new PointMass(sf::Vector2f(400, 200))
  });
  connectors.insert(connectors.end(), {
    new Spring(sf::Vector2u(0, 1)),
    new Spring(sf::Vector2u(1, 2)),
    new Spring(sf::Vector2u(2, 0)),
    new Spring(sf::Vector2u(3, 4), 200.0f),
    new Spring(sf::Vector2u(4, 5), 200.0f),
    new Spring(sf::Vector2u(5, 3), 200.0f)
  });
  meshes.insert(meshes.end(), {
    new Collider({0, 1, 2}),
    new Collider({3, 4, 5})
  });*/


  sf::RenderWindow SCREEN(sf::VideoMode(512, 512), "Sandbox");
  SCREEN.setFramerateLimit(60);
  SCREEN.setView(cam);
  while (SCREEN.isOpen()) {
    sf::Event event;
    while (SCREEN.pollEvent(event)) {
      switch (event.type) {
        case sf::Event::Closed:
          SCREEN.close();
          break;
        case sf::Event::KeyPressed:
          if (event.key.code == sf::Keyboard::Space) pause = !pause;
          break;
        case sf::Event::MouseButtonPressed: {
          if (event.mouseButton.button == sf::Mouse::Left)
            for (int p = 0; p < particles.size(); p++) 
              if (distance(SCREEN.mapPixelToCoords(sf::Vector2i(event.mouseButton.x, event.mouseButton.y)), particles[p]->pos) <= ((PointMass*)particles[p])->mass)
                held = p;
          if (event.mouseButton.button == sf::Mouse::Right) {
            if (selected == pointMass) {
              particles.push_back(new PointMass(SCREEN.mapPixelToCoords(sf::Vector2i(event.mouseButton.x, event.mouseButton.y))));
            } else if (selected < collider) {
              for (int p = 0; p < particles.size(); p++)
                if (distance(SCREEN.mapPixelToCoords(sf::Vector2i(event.mouseButton.x, event.mouseButton.y)), particles[p]->pos) <= ((PointMass*)particles[p])->mass) {
                  if (selected == spring) {
                    connectors.push_back(new Spring());
                    held = -2;
                  }
                  if (selected == rope) {
                    connectors.push_back(new Rope());
                    held = -4;
                  }
                  connectors.back()->connections.x = p;
                  connectors.back()->connections.y = p;
              }
            } else {
              for (int p = 0; p < particles.size(); p++)
                if (distance(SCREEN.mapPixelToCoords(sf::Vector2i(event.mouseButton.x, event.mouseButton.y)), particles[p]->pos) <= ((PointMass*)particles[p])->mass) {
                  meshes.push_back(new Collider());
                  held = -3;
                  meshes.back()->vertices.push_back(p);
                }
            }
          }
          break;
        }
        case sf::Event::MouseButtonReleased:
          held = -1;
          break;
        case sf::Event::MouseWheelMoved:
          cam.zoom(0.9f - (float)event.mouseWheel.delta*0.2f);
          SCREEN.setView(cam);
      }
    }

    if (UI.particleSelect) {
      selected = pointMass;
    }
    if (UI.springSelect) {
      selected = spring;
    }
    if (UI.ropeSelect) {
      selected = rope;
    }
    if (UI.colliderSelect) {
      selected = collider;
    }

    if (sf::Keyboard::isKeyPressed(sf::Keyboard::W) || sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
      cam.move(sf::Vector2f(0.0f, -0.01f*cam.getSize().y));
      SCREEN.setView(cam);
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::S) || sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
      cam.move(sf::Vector2f(0.0f, 0.01f*cam.getSize().y));
      SCREEN.setView(cam);
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::A) || sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
      cam.move(sf::Vector2f(-0.01f*cam.getSize().x, 0.0f));
      SCREEN.setView(cam);
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::D) || sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
      cam.move(sf::Vector2f(0.01f*cam.getSize().x, 0.0f));
      SCREEN.setView(cam);
    }
    
    if ((held == -2 || held == -4) && selected >= spring && selected <= rope && sf::Mouse::isButtonPressed(sf::Mouse::Right)) {
      sf::Vector2f mPos(SCREEN.mapPixelToCoords(sf::Mouse::getPosition(SCREEN)));
      for (int p = 0; p < particles.size(); p++) {
        if (connectors.back()->connections.x != p && distance(mPos, particles[p]->pos) <= ((PointMass*)particles[p])->mass) {
          if (held == -2) {
            ((Spring*)connectors.back())->setHomeDis(distance(
              particles[connectors.back()->connections.x]->pos, 
              particles[connectors.back()->connections.y]->pos
            ));
          } else {
            ((Rope*)connectors.back())->homeDis = distance(
              particles[connectors.back()->connections.x]->pos, 
              particles[connectors.back()->connections.y]->pos
            );
          }
          connectors.back()->connections.y = p;
        }
      }
    }

    if (held == -3 && selected >= collider && sf::Mouse::isButtonPressed(sf::Mouse::Right)) {
      sf::Vector2f mPos(SCREEN.mapPixelToCoords(sf::Mouse::getPosition(SCREEN)));
      for (int p = 0; p < particles.size(); p++) 
        if (meshes.back()->vertices.back() != p && distance(mPos, particles[p]->pos) <= ((PointMass*)particles[p])->mass) {
          meshes.back()->vertices.push_back(p);
        }
    }

    if (pause) {
      
    } else {
      for (int c = 0; c < connectors.size(); c++) {
        connectors[c]->update();
      }

      for (int p = 0; p < particles.size(); p++) {
        ((PointMass*)particles[p])->velocity.y += 0.1f;
        if (((PointMass*)particles[p])->pos.y > 512 && ((PointMass*)particles[p])->velocity.y > 0.0f) {
          particles[p]->pos.y = 512;
          ((PointMass*)particles[p])->velocity = -((PointMass*)particles[p])->velocity*((PointMass*)particles[p])->bounciness;
        }
        ((PointMass*)particles[p])->update(particles);
      }

      for (int m = 0; m < meshes.size(); m++)
        ((Collider*)meshes[m])->update(meshes);
    }

    if (held > -1) {
      sf::Vector2f mPos(SCREEN.mapPixelToCoords(sf::Mouse::getPosition(SCREEN)));
      if (pause)
        particles[held]->pos = mPos;
      else
        ((PointMass*)particles[held])->velocity = sf::Vector2f(mPos-particles[held]->pos);
    }
    SCREEN.clear();

    if (UI.particleVisible)
      for (int p = 0; p < particles.size(); p++)
        particles[p]->draw(SCREEN);

    for (int c = 0; c < connectors.size(); c++) {
      Spring* compare = dynamic_cast<Spring*>(connectors[c]);
      if (UI.springVisible && compare != nullptr) {
        connectors[c]->draw(SCREEN);
      } else if (UI.ropeVisible && compare == nullptr) {
        connectors[c]->draw(SCREEN);
      }
    }

    if (UI.colliderVisible)
      for (int m = 0; m < meshes.size(); m++)
        meshes[m]->draw(SCREEN);

    if (pause) {
      UI.draw(SCREEN);
    }
    
    SCREEN.display();

    SCREEN.setTitle("fps: "+std::to_string(int(fpsClock.get_fps())));
  }
  return 0;
}

void softBox(int width, int height, int size) {
  for (int y = 0; y < height; y++)
    for (int x = 0; x < width; x++) {
      particles.push_back(new PointMass(sf::Vector2f(x*size+(y % 2), -y*size), 10.0f));
      if (x > 0) {
        connectors.push_back(new Spring(size));
        connectors.back()->connections.x = particles.size()-1;
        connectors.back()->connections.y = particles.size()-2;
        ((Spring*)connectors.back())->durability = 150;
      }
      if (y > 0) {
        connectors.push_back(new Spring(size));
        connectors.back()->connections.x = particles.size()-1;
        connectors.back()->connections.y = particles.size()-(width+1);
        ((Spring*)connectors.back())->durability = 150;
      }
      if (x > 0 && y > 0) {
        connectors.push_back(new Spring(distance(particles.back()->pos, particles[particles.size()-(width+2)]->pos)));
        connectors.back()->connections.x = particles.size()-1;
        connectors.back()->connections.y = particles.size()-(width+2);
        ((Spring*)connectors.back())->durability = 150;
      }
      if (x < (width-1) && y > 0) {
        connectors.push_back(new Spring(distance(particles.back()->pos, particles[particles.size()-width]->pos)));
        connectors.back()->connections.x = particles.size()-1;
        connectors.back()->connections.y = particles.size()-width;
        ((Spring*)connectors.back())->durability = 150;
      }
      /*if (x+y > 0) {
        connectors.push_back(new Rope(size));
        connectors.back()->connections.x = particles.size()-1;
        connectors.back()->connections.y = particles.size()-2;
      }*/
    }
}
