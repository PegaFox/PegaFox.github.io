class Object {
  public:
    virtual void draw(sf::RenderTarget& SCREEN) = 0;
};