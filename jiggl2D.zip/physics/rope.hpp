class Rope : public Connector {
  public:
    float homeDis;
    float stiffness = 1.0f;
    float damping = 1.0f;
    uint32_t durability = -1;

    Rope() {
      sprite.setPrimitiveType(sf::Lines);
      sprite.resize(2);
    }

    Rope(float newMaxDis) {
      homeDis = newMaxDis;

      sprite.setPrimitiveType(sf::Lines);
      sprite.resize(2);
    }

    void update() {
      if (connections.x == connections.y) return;

      float offset = distance(particles[connections.x]->pos, particles[connections.y]->pos) - homeDis;
      if (offset <= 0) return;
      if (offset > durability) {
        connections = sf::Vector2u(-1, -1);
        return;
      }

      sf::Vector2f dir = particles[connections.x]->pos - particles[connections.y]->pos;
      float dis = distance(sf::Vector2f(), dir);
      if (dis != 0.0f)
        dir /= dis;
      else
        dir = sf::Vector2f(0, 0);
      float force = offset * stiffness + dotProduct(dir, ((PointMass*)particles[connections.x])->velocity - ((PointMass*)particles[connections.y])->velocity) * damping;
      ((PointMass*)particles[connections.x])->addForce(-dir * force);
      ((PointMass*)particles[connections.y])->addForce(dir * force);
    }

    void draw(sf::RenderTarget& SCREEN) {
      if (connections.x == connections.y) return;

      sprite[0].position = particles[connections.x]->pos;
      sprite[1].position = particles[connections.y]->pos;
      SCREEN.draw(sprite);
    }
  private:
    sf::VertexArray sprite;
};