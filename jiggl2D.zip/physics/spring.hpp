class Spring : public Connector {
  public:
    float stiffness = 1.0f;
    float damping = 1.0f;
    uint32_t durability = -1;

    Spring() {
      setHomeDis(100);
      sprite.setPrimitiveType(sf::LineStrip);
    }

    Spring(float homeDis, const sf::Vector2u& connections = {0U, 0U}) {
      setHomeDis(homeDis);
      this->connections = connections;
      sprite.setPrimitiveType(sf::LineStrip);
    }

    Spring(const sf::Vector2u& connections, float homeDis = 100.0f) {
      this->connections = connections;
      setHomeDis(homeDis);
      sprite.setPrimitiveType(sf::LineStrip);
    }

    void setHomeDis(float newHomeDis) {
      homeDis = newHomeDis;
      sprite.resize(floor(homeDis/10)+1);
    }

    float getHomeDis() {
      return homeDis;
    }

    void update() {
      if (connections.x == connections.y) return;

      float offset = distance(particles[connections.x]->pos, particles[connections.y]->pos) - homeDis;
      if (abs(offset) > durability) {
        connections = sf::Vector2u(-1, -1);
        return;
      }

      sf::Vector2f dir = particles[connections.x]->pos - particles[connections.y]->pos;
      float dis = distance(sf::Vector2f(), dir);
      if (dis != 0.0f)
        dir /= dis;
      else
        dir = sf::Vector2f(0, 0);
      float force = offset * stiffness + dotProduct(dir, ((PointMass*)particles[connections.x])->velocity - ((PointMass*)particles[connections.y])->velocity) * damping;
      ((PointMass*)particles[connections.x])->addForce(-dir * force);
      ((PointMass*)particles[connections.y])->addForce(dir * force);
    }

    void draw(sf::RenderTarget& SCREEN) {
      if (connections.x == connections.y) return;

      sf::Vector2f pos = particles[connections.x]->pos;
      sf::Vector2f step = (particles[connections.y]->pos - particles[connections.x]->pos) / floorf(homeDis/10);
      int mult = 1;
      float dis = distance(sf::Vector2f(), step);
      if (sprite.getVertexCount() > 1) {
        for (int p = 0; p <= floor(homeDis/10); p++) {
          sprite[p].position = pos;
          pos += (step+(sf::Vector2f(step.y*mult, step.x*-mult)/(dis/10)));
          mult = -mult;
        }
        SCREEN.draw(sprite);
      }
    }

  private:
    sf::VertexArray sprite;
    float homeDis;
};