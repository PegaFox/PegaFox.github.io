class FPS {
  public:
    float fps;
    int fpsCount = 0;
    float get_fps() {
      time = elapsed.restart();
      fps = 1/time.asSeconds();

      fpsCount++;
      return fps;
    }

    float getLastTime() {
      return time.asSeconds();
    }

  private:
    int lastFpsCount;
    sf::Clock elapsed;
    sf::Time time;
};

float distance(const sf::Vector2f& pos1, const sf::Vector2f& pos2) {
  sf::Vector2f diff(pos1.x-pos2.x, pos1.y-pos2.y);
  return sqrt(diff.x*diff.x + diff.y*diff.y);
}

sf::Vector2f normalize(const sf::Vector2f& vec) {
  return vec / distance(sf::Vector2f(0.0f, 0.0f), vec);
}

float dotProduct(const sf::Vector2f& in1, const sf::Vector2f& in2) {
  return in1.x * in2.x + in1.y * in2.y;
}

sf::Vector2f reflect(const sf::Vector2f& dirIn, const sf::Vector2f& normal) {
  return dirIn - 2*dotProduct(dirIn, normal)*normal;
}

class Toggle {
  private:
    bool *var;
  public:
    sf::Color onColor;
    sf::Color offColor;
    sf::RectangleShape outerBox;
    sf::RectangleShape flip;
    sf::Font font;
    sf::Text label;

    sf::FloatRect rect;

    Toggle(bool *value = nullptr) : var{value} {
      rect.left = *value * 16;
      rect.width = 16;
      rect.height = 16;

      onColor = sf::Color::Green;
      offColor = sf::Color::Red;
      
      outerBox.setSize(sf::Vector2f(rect.width*2, rect.height));
      outerBox.setFillColor(*value ? onColor : offColor);

      flip.setSize(sf::Vector2f(rect.width, rect.height));
      flip.setFillColor(sf::Color(200, 200, 200));
      flip.setPosition(sf::Vector2f(rect.left, rect.top));

      label.setCharacterSize(rect.height);
    }

    void setValue(bool *value) {
      var = value;
    }

    void setPosition(const sf::Vector2f& newPos) {
      rect.left = newPos.x+(*var * rect.width);
      rect.top = newPos.y;
      outerBox.setPosition(newPos);
      flip.setPosition(sf::Vector2f(rect.left, rect.top));
      label.setPosition(newPos);
    }

    void setSize(const sf::Vector2f& newSize) {
      rect.width = newSize.x/2;
      rect.height = newSize.y;
      outerBox.setSize(newSize);
      flip.setSize(sf::Vector2f(newSize.x/2, newSize.y));
      label.setCharacterSize(newSize.y);
    }

    void setFrontColor(sf::Color& newColor) {
      flip.setFillColor(newColor);
    }

    void setBackOnColor(sf::Color& newColor) {
      onColor = newColor;
    }

    void setBackOffColor(sf::Color& newColor) {
      offColor = newColor;
    }

    void setFont(const std::string& newFont) {
      font.loadFromFile(newFont);
      label.setFont(font);
    }

    void setCaption(const sf::String& newCaption) {
      label.setString(newCaption);
    }

    void setTextColor(const sf::Color& newColor) {
      label.setFillColor(newColor);
    }

    void update(sf::RenderTarget& SCREEN, sf::Window& display) {
      sf::Vector2f mPos;

      rect.left = outerBox.getPosition().x+(*var * rect.width);
      flip.setPosition(sf::Vector2f(rect.left, rect.top));

      if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
        mPos = SCREEN.mapPixelToCoords(sf::Mouse::getPosition(display));
        if (rect.contains(mPos.x, mPos.y))
          *var = !*var;
          outerBox.setFillColor(*var ? onColor : offColor);
      }
 
      SCREEN.draw(outerBox);
      SCREEN.draw(flip);
      SCREEN.draw(label);
    }
};

class Button {
  private:
    bool *var;
    bool pressed = false;
  public:
    sf::Color onColor;
    sf::Color offColor;
    sf::RectangleShape box;
    sf::Font font;
    sf::Text label;

    sf::FloatRect rect;

    Button(bool *value = nullptr) : var{value} {
      rect.width = 16;
      rect.height = 16;

      onColor = sf::Color(200, 200, 200);
      offColor = sf::Color(100, 100, 100);
      
      box.setSize(sf::Vector2f(rect.width, rect.height));
      box.setFillColor(*value ? onColor : offColor);

      label.setCharacterSize(rect.height);
    }

    void setValue(bool *value) {
      var = value;
    }

    void setPosition(const sf::Vector2f& newPos) {
      rect.left = newPos.x;
      rect.top = newPos.y;
      box.setPosition(newPos);
      label.setPosition(newPos);
    }

    void setSize(const sf::Vector2f& newSize) {
      rect.width = newSize.x;
      rect.height = newSize.y;
      box.setSize(newSize);
      label.setCharacterSize(newSize.y);
    }

    void setOnColor(sf::Color& newColor) {
      onColor = newColor;
    }

    void setOffColor(sf::Color& newColor) {
      offColor = newColor;
    }

    void setFont(const std::string& newFont) {
      font.loadFromFile(newFont);
      label.setFont(font);
    }

    void setCaption(const sf::String& newCaption) {
      label.setString(newCaption);
    }

    void setTextColor(const sf::Color& newColor) {
      label.setFillColor(newColor);
    }

    void update(sf::RenderTarget& SCREEN, sf::Window& display) {
      sf::Vector2f mPos;

      if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
        mPos = SCREEN.mapPixelToCoords(sf::Mouse::getPosition(display));
        if (rect.contains(mPos.x, mPos.y)) {
          *var = true;
          pressed = true;
        } else if (pressed) {
          *var = false;
          pressed = false;
        }
        box.setFillColor(*var ? onColor : offColor);
      } else if (pressed) {
        *var = false;
        pressed = false;
        box.setFillColor(*var ? onColor : offColor);
      }
      
      SCREEN.draw(box);
      SCREEN.draw(label);
    }
};