class PointMass : public Particle {
  public:
    sf::Vector2f velocity;
    float bounciness = 0.1f;
    float collisionRadius = 0.0f;
    float mass;

    PointMass() {
      mass = 10.0f;
      sprite.setOutlineThickness(1.0f);
    }

    PointMass(const sf::Vector2f& pos, float mass = 10.0f, float collisionRadius = 0.0f) {
      this->pos = pos;
      this->mass = mass;
      this->collisionRadius = collisionRadius;
      sprite.setOutlineThickness(1.0f);
    }

    void addForce(sf::Vector2f force) {
      force /= mass;
      force *= 0.8f;
      velocity += force;
    }

    void update(std::vector<Particle*>& particles) {
      
      if (collisionRadius > 0.0f) {
        for (int p = 0; p < particles.size(); p++) {
          float dis = distance(pos, particles[p]->pos);
          if (dis > 0 && dis < collisionRadius+((PointMass*)particles[p])->collisionRadius) {
            sf::Vector2f ang(pos - particles[p]->pos);
            ang /= dis;
            velocity += ang*((collisionRadius+((PointMass*)particles[p])->collisionRadius)-dis);
          }
        }
      }

      if (!fixed)
        pos += velocity;
    }

    void draw(sf::RenderTarget& SCREEN) {
      sprite.setFillColor(sf::Color::White);
      sprite.setRadius(mass);
      sprite.setOrigin(sf::Vector2f(mass, mass));
      sprite.setPosition(pos);
      SCREEN.draw(sprite);
      sprite.setFillColor(sf::Color::Transparent);
      sprite.setRadius(collisionRadius);
      sprite.setOrigin(sf::Vector2f(collisionRadius, collisionRadius));
      SCREEN.draw(sprite);
    }
};